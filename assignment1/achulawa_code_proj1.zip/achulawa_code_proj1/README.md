# 16-825 Assignment 1: Rendering Basics with PyTorch3D (Total: 100 Points + 10 Bonus)

**Instructions for Usage**

Navigate to the root folder 'achulawa_code_proj1' where the main.py is located. This ensures relative path references are maintained. Standard setup where pytorch3d is installed should be sufficient in terms of package references. 

The main script contains all function required, with the utils scipt providing extra utilities.

Simply running the main script should generate all the results for all questions. Results present in the results directory. The main call is commented to better understand what part of the script finds the solution to which question. 

Let me know if you have any particular questions (achulawa@andrew.cmu.edu). I am running this on a Linux System (Ubuntu 18).